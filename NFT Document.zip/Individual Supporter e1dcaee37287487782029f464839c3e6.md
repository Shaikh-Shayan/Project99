# Individual Supporter

“Longhorn NFT Drop”

“This NFT drop is a very special drop that will fuel the global growth of Web3 Texas to Web3 Earth. Check out our road map below to see exactly what this means and how we plan on achieving it. “

![6.png](Individual%20Supporter%20e1dcaee37287487782029f464839c3e6/6.png)

- niftify.io
- Lazy Mint
- Allowlist accessible only by Web3 Texas Team
- Cost 1 Eth
- Airdrop a Member Pass NFT with a 5 year burn rate in contract
- Reveation Labs Decision: Ethereum or Polygon

**Member Pass**

- Member Pass
- [https://nftpay.xyz/](https://nftpay.xyz/)
- Lazy Mint
- Allowlist accessible only by Web3 Texas Team
- Cost .1 Eth
- Reveation Labs Decision: Polygon
- Contract must burn at 1 year
    
    ![4.gif](Individual%20Supporter%20e1dcaee37287487782029f464839c3e6/4.gif)
    

**Community Builder Passes**

“Community Builder passes are non-sellable, non-purchasable and non-transferable NFTs (Soul Bound Tokens). They symbolize association with or work contributions to the Web3 Texas Community.”

- Reveation Labs Question: Are Soul Bound Tokens live in production as an ERC standard? If yes, please use for this
- Content Contributor Pass (only issued via Allowlist) - this is a pass that will be airdropped to a select individuals in the Texas Web3 community who help the Web3 Texas staff create and curate content
- User will be airdropped pass, then come to the site to redeem and mint
    
    ![6.gif](Individual%20Supporter%20e1dcaee37287487782029f464839c3e6/6.gif)
    
- Social Ambassador Pass (mint via allowlist):
- User will be airdropped pass, then come to the site to redeem and mint:

![Social Ambsdr.gif](Individual%20Supporter%20e1dcaee37287487782029f464839c3e6/Social_Ambsdr.gif)